/* I forhold til den normale SUPERSAB er der �ndret i flg. linienr.:
   104,204,642,676
   663,698 (EW=0 istedetfor EW=-epsilon*weights */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#define bool int
#define TRUE 1
#define FALSE 0
#define g(h,a) (1 / (1 + exp(-(a)*(h))))   /* The activation function */
#define sqr(x) ((x)*(x))
#define abs(x) ( (x<0) ? (-x) : (x) )
/* #define wrandom() ( (((double) lrand48()) / 1073741823.0) - 1.0 ) */
#define wrandom() ( (((double) rand()) / (RAND_MAX/2.0) ) - 1.0 )

#define HID_UNITS 20



void stat()
{
  int i,run,no_runs;
  double gen1,gen15;
  double VSgen1,VSSQgen1,VSgen15,VSSQgen15,Sgen1,SSQgen1,Sgen15,SSQgen15;
  double etam,etap,alfa;
  FILE *fp1,*fp2,*fopen();
  
  fp1=fopen("ind","r");
  fp2=fopen("ud","w"); fclose(fp2);


  for(i=0;i<10;i++)
    {
      Sgen1=SSQgen1=Sgen15=SSQgen15=0.0;
      VSgen1=VSSQgen1=VSgen15=VSSQgen15=0.0;
      fscanf(fp1,"%lf %lf %lf %d",&etam,&etap,&alfa,&no_runs);
      for (run=0; run < no_runs; run++)
	{
	  fscanf(fp1,"%lf %lf",&gen1,&gen15);
	  Sgen1+=gen1; SSQgen1+=gen1*gen1;
	  Sgen15+=gen15; SSQgen15+=gen15*gen15;
	}
      
      Sgen1/=no_runs; Sgen15/=no_runs; SSQgen1/=no_runs; SSQgen15/=no_runs;
      
      fp2=fopen("ud","a");
      fprintf(fp2,"eta-: %.2f  eta+: %.2f  alfa: %.2f\n",etam,etap,alfa);
      fprintf(fp2,"(%d) %.2f %.2f %.2f %.2f\n",no_runs,
	      Sgen1, sqrt((SSQgen1-Sgen1*Sgen1)),
	      Sgen15, sqrt((SSQgen15-Sgen15*Sgen15)));
      fclose(fp2);
      
    }
}
  


void main(argc,argv)
     int argc;
     char *argv[];
{
  stat();
}
